﻿using UnityEngine;
using System.Collections;

namespace Match2 {
		
	public class GridManager
    {

		/*
		 * This class is responsible for creating and managing the card views and manipulating 
		 *  card models as the game progresses
		 */

		public static GridManager _instance;
		public static GridManager GetInstance() {

			if (_instance == null) {
				_instance = new GridManager();
				_instance.Initialize ();
			}

			return _instance;
		}
			
		// vars
		private CardView[] cardViews;
		private int GridX, GridY;

		// root transform
		Transform rootTransform;

		private void Initialize() {
		}

		// Initialization

		public void CreateGrid(Match2State state) {
			
			if (state.matchLength == 0 || state.GridX == 0 || state.GridY == 0) {
				Debug.LogError ("Cannot create card grid, state not initialized.");
				return;
			}

			int matchLength = state.matchLength;
            GridX = state.GridX;
            GridY = state.GridY;
			int deckSize = GridX * GridY;
			int faceTypesCount = (deckSize % matchLength);

			if (faceTypesCount > 0) {
				Debug.LogError ("Decksize is not divisible by MatchLength, cannot create deck.");
				return;
			}

			// instantiate the root object
			GameObject root = GameObject.Find(GlobalVars.RootObjectName);
			if (root == null) {
				Debug.LogError ("Cannot find root object.");
				return;
			}
			rootTransform = root.transform;

			// position the root object
			CenterRootObject(state);

			// create the card models
			CardModel[] cardModels = new CardModel[deckSize];
			int faceType = 1;

			// for each face type
			for (int i = 0; i < deckSize; i += matchLength) {
				// create that many cards
				for (int j = 0; j < matchLength; j++) {
					int index = i + j;
					cardModels [index] = new CardModel ();
					cardModels [index].FaceValue = faceType;
				}
				faceType++;
			}

			state.cards = cardModels;
		}	

		public void ShuffleGrid(Match2State state) {
			// use fisher-yates shuffle to re-arrange the array
			CardModel[] cards = state.cards;
			int n = cards.Length;
			System.Random rand = new System.Random ();

			for (int i = 0; i < n; i++) {
				int r = i + (int)(rand.NextDouble () * (n - i));
				CardModel temp = cards [r];
				cards [r] = cards [i];
				cards [i] = temp;
			}

			state.cards = cards;
		}

		// Initialize the card view objects and face textures
		public void InitializeGridCardViews (Match2State state) {

			CardModel[] cardModels = state.cards;
			cardViews = new CardView[cardModels.Length];

			Vector3 origin = new Vector3 (0f, 0f, 0f);

			for (int x = 0; x < GridX; x++) {
				for (int y = 0; y < GridY; y++) {
					GameObject cardObj = new GameObject ("card");
					int idx = IdxForGridPos (x, y);
					CardView cardView = cardObj.AddComponent<CardView> ();
					cardViews [idx] = cardView;
                    cardView.refIdx = idx;
                    cardView.transform.SetParent (rootTransform);
                    cardView.transform.localPosition = origin + new Vector3 (x, y, 0);
				}
			}
		}

		public void Spacing(Match2State state) {

			// Instantly set card spacing, animated version can come later
			float xSpacing = GlobalVars.CardXSpacing;
			float ySpacing = GlobalVars.CardYSpacing;
			float yMultiplier = GlobalVars.CardAspect;

			Vector3 origin = new Vector3 (0f, 0f, 0f);

			for (int x = 0; x < GridX; x++) {
				for (int y = 0; y < GridY; y++) {
					int idx = IdxForGridPos (x, y);
					Transform t = cardViews [idx].transform;
					Vector3 position = new Vector3 (
						x + x*xSpacing, 
						y*yMultiplier + y*ySpacing, 
						0f);
					t.localPosition = origin + position;
				}
			}
		}

		public void CenterRootObject(Match2State state) {
            // work out the width of the grid and the height of the grid
            //  position the grid based on this offset

            float cardWidth = GlobalVars.CardWidth;
            float boardWidth = cardWidth * GridX;
            float xSpacing = GlobalVars.CardXSpacing * (GridX - 1);
            float xOffset = (boardWidth / 2) + (xSpacing / 2) - (cardWidth / 2);

            float cardHeight = GlobalVars.CardWidth * GlobalVars.CardAspect;
            float boardHeight = cardHeight * GridY;
            float ySpacing = GlobalVars.CardYSpacing * (GridY - 1);
            float yOffset = (boardHeight / 2) + (ySpacing / 2) - (cardHeight / 2);
            
            Vector3 position = rootTransform.localPosition;
            position.x = -xOffset;
            position.y = -yOffset;
            rootTransform.localPosition = position;
		}

		public void Textures(Match2State state) {

			// Give cards the face textures associated with their face type
			CardModel[] cards = state.cards;
			int deckSize = cards.Length;

            GameConfig gc = GlobalVars.GameStateConfig;
			int deckTextureIdx = gc.deckTextureIdx;
			Texture2D deckTex = CardTexturesManager.GetInstance ().GetDeckTexture(deckTextureIdx);

			for (int i = 0; i < deckSize; i++) {
				
				int faceValue = cards [i].FaceValue;
				Texture2D faceTex = CardTexturesManager.GetInstance ().GetFaceTexture(faceValue);
				cardViews [i].SetFaceTexture (faceTex);
				cardViews [i].SetDeckTexture (deckTex);
			}
		}

		// Animations

		public void FlipAllCardsUp(){

			if (cardViews == null) {
				Debug.LogError ("Error: Cannot flip cards, CardGridManager not initialized!");
			}

			for (int i = 0; i < cardViews.Length; i++) {
                CardView cardView = cardViews [i];
				cardView.FlipUp ();
			}
		}

		public void FlipAllUnmatchedCardsDown () {
			if (cardViews == null) {
				Debug.LogError ("Error: Cannot flip cards, CardGridManager not initialized!");
			}

			for (int i = 0; i < cardViews.Length; i++) {
				CardView cardView = cardViews [i];
				if (!cardView.isMatched)
					cardView.FlipDown ();
			}
		}

		public void FlipAllCardsDown() {
			if (cardViews == null) {
				Debug.LogError ("Error: Cannot flip cards, CardGridManager not initialized!");
			}

			for (int i = 0; i < cardViews.Length; i++) {
				CardView cardView = cardViews [i];
                cardView.FlipDown ();
			}
		}

		public void Look(float delay, float LookTime)
        {
			DummyObject.GetInstance().StartCoroutine (PeekAnimation(delay, LookTime));
		}

		IEnumerator PeekAnimation(float delay, float LookTime)
        {

			yield return new WaitForSeconds (delay);

            GridManager gm = GridManager.GetInstance ();
            gm.FlipAllCardsUp ();

			yield return new WaitForSeconds (LookTime);

            gm.FlipAllCardsDown ();
		}

		// Utilities

		public void SetCardViewsMatched(int[] indexes){
			for (int i = 0; i < indexes.Length; i++) {
				SetCardViewMatched (indexes [i]);
			}
		}

		public void SetCardViewMatched(int idx) {
			cardViews [idx].SetMatched ();
		}

		public int IdxForGridPos(int x, int y){
			//Debug.Log ("IdxForGridPos: " + x + ":" + y + " is " + (y + (x * grid_x)));
			return y + (x * GridY);
		}

		public Vector2 GridPositionForIdx(int idx){
			int x = (int)(idx / GridX);
			int y = (int)(idx % GridX);
			//Debug.Log ("GridPosForIdx: " + idx + " is " + x + ":" + y);
			return new Vector2 (x, y);
		}

		public CardView GetCardViewForGridPosition (int x, int y) {
			return cardViews[IdxForGridPos(x, y)];
		}


	}
}