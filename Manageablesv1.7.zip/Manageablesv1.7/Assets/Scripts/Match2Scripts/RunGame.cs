﻿using UnityEngine;
using System.Collections;


namespace Match2 { //using namespace to avoid overlaps with other minigames and scripts. Match2 as its the name of the game. 
		
	public class RunGame : MonoBehaviour { //this script servers as a bootstrap for the entire minigame. Loads stuff on startup. 

		void Awake ()
        {		
			InstantiateBackground();
			InstantiateSceneTransitionsPrefab();
			InstantiateGameMenu();
		}

		void InstantiateBackground()
        {			
			GameObject bg_prefab = Resources.Load(AppVars.BackgroundPrefabLocation) as GameObject;

			if(bg_prefab != null){
                GameObject background = Instantiate(bg_prefab);
				background.name = "background_quad";
                background.SetActive(true);
			} else {
				Debug.LogError("Background Prefab not found");
			}
		}

		void InstantiateSceneTransitionsPrefab()
        {
			GameObject transitions_animation_prefab = Resources.Load(AppVars.ScreenTransitionsAnimationPrefabLocation) as GameObject;

			if(transitions_animation_prefab != null){
                GameObject screen_transitions_animation_controller = Instantiate(transitions_animation_prefab);
				screen_transitions_animation_controller.name = "screen_transitions_animation";
                screen_transitions_animation_controller.SetActive(true); 
            } else {
				Debug.LogError("Transition prefab not found");
			}
		}

		void InstantiateGameMenu()
        {		
			GameObject menu_prefab = Resources.Load(AppVars.MainMenuPrefabLocation) as GameObject;

			if(menu_prefab != null){
                GameObject menu = Instantiate(menu_prefab);
				menu.name = AppVars.MainMenuRootName;
                menu.SetActive(true);
            } else {
				Debug.LogError("Error Prefab not found");
			}
		}
	}
}