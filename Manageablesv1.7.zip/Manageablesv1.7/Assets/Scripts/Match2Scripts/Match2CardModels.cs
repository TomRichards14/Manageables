﻿using UnityEngine;
using System.Collections;

namespace Match2 {
	
	public class CardModel {
		public int FaceValue { get; set; }
		public bool RevealedState { get; set; } //true when card is flipped.
		public bool MatchedState { get; set; } //true when card is matched.

		public CardModel()
        {
			FaceValue = -1;
			RevealedState = false;
			MatchedState = false;
		}

		public bool FaceMatches(CardModel otherCard)
        {
			return FaceMatches (otherCard.FaceValue);
		}

		public bool FaceMatches(int otherFaceValue)
        {
			return FaceValue == otherFaceValue;
		}
	}
}
