﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

	namespace Match2 {

	public class MenuGameConfigurator : MonoBehaviour {

		// this script will listen to the options menu in order to configure the game!
        
        // internal vars 
		private int gridX;
		private int gridY;
        private int matchLength;
		private bool showPeek;

        // separate script for deck preview
        public MenuDeckPreview deckPreview;

        // ui elements
        public Slider GridX_slider;
		public Slider GridY_slider;
        public Dropdown match_length_dropdown;
		public Toggle peek_toggle;
		public Toggle timer_toggle;

        // match length dropdown optiondata
        private List<Dropdown.OptionData> match_length_options;

        // labels
        public Text lbl_GridX;
        public Text lbl_GridY;

		// Use this for initialization
		void Awake () {

			SetMenuConstraintsAndDefaults();
		}

		void SetMenuConstraintsAndDefaults() {
            // gather min/max values for these options and set them
            int min_x = GlobalVars.MinGridX;
            int max_x = GlobalVars.MaxGridX;
            int default_x = GlobalVars.GameDefaults_GridX;

            int min_y = GlobalVars.MinGridY;
            int max_y = GlobalVars.MaxGridY;
            int default_y = GlobalVars.GameDefaults_GridY;

            // min/max/default for grid width
            GridX_slider.minValue = min_x;
            GridX_slider.maxValue = max_x;
            GridX_slider.value = default_x;
            gridX = default_x;

            // min/max/default for grid height
            GridY_slider.minValue = min_y;
            GridY_slider.maxValue = max_y;
            GridY_slider.value = default_y;
            gridY = default_y;

            // update labels to match the sliders
            lbl_GridX.text = GridX_slider.value.ToString();
            lbl_GridY.text = GridY_slider.value.ToString();

            // peek toggle
            showPeek = GlobalVars.GameDefaults_ShowPeekAnimation;
            peek_toggle.isOn = showPeek;

            // set initial values for our match length dropdown
            RecalculateMatchLengthOptions();

            // initialise default config
            UpdateConfig();
        }

        // evaluate the match length options
        void RecalculateMatchLengthOptions ()
        {
            match_length_options = new List<Dropdown.OptionData>();
            // todo: this could be re-written as an array of potentially valid ones (in GameVars), then loop through it
            //          and build the list that way
            int totalCards = gridX * gridY;

            if (totalCards % 2 == 0)
            {
                match_length_options.Add(new Dropdown.OptionData("2"));
            }
            
            if (totalCards % 3 == 0)
            {
                match_length_options.Add(new Dropdown.OptionData("3"));
            }
            
            if (totalCards % 4 == 0 && totalCards > 4)
            {
                match_length_options.Add(new Dropdown.OptionData("4"));
            }

            if (totalCards % 5 == 0 && totalCards > 5)
            {
                match_length_options.Add(new Dropdown.OptionData("5"));
            }

            match_length_dropdown.options = match_length_options;
            UpdateMatchLengthSelection(0); // set to first options
            
            UpdateConfig();
        }

        // helper method for calling everything we need on a value update
        void ValueWasUpdated()
        {
            RecalculateMatchLengthOptions();
            UpdateLabels();
            UpdateConfig();
        }

        // update config from out internal variables
        public void UpdateConfig()
        {

            // Configure
            GameConfig gc = new GameConfig();
            if (gridX > 0)
                gc.GridX = gridX;
            if (gridY > 0)
                gc.GridY = gridY;
            if (matchLength > 1)
                gc.matchLength = matchLength;
            if (deckPreview != null)
                gc.deckTextureIdx = deckPreview ? deckPreview.GetDeckIndex() : 0;
            //  card peek animation
            gc.showPeekAnimation = showPeek;
            // todo show timer

            // Initialize global vars
            GlobalVars.GameStateConfig = gc;
        }     

        void UpdateMatchLengthSelection(int dropdownValue)
        {
            // update the selection itself
            string selected = match_length_dropdown.options[match_length_dropdown.value].text;
            int selectedMatchLen = 2;
            if (!int.TryParse(selected, out selectedMatchLen))
            {
                Debug.LogError("Could not parse match length string...");
            }

            matchLength = selectedMatchLen;
        }

        // should be called AFTER a variable is updated
        void UpdateLabels()
        {
            if (lbl_GridX != null)
            {
                lbl_GridX.text = gridX.ToString();
            }

            if (lbl_GridY != null)
            {
                lbl_GridY.text = gridY.ToString();
            }
        }

        // UI interaction points		

        public void SetGridX(float value){
			gridX = (int)value;
            ValueWasUpdated();
        }

		public void SetGridY(float value){
			gridY = (int)value;
            ValueWasUpdated();
        }

		public void SetMatchLength(int value){
            UpdateMatchLengthSelection(value);
            ValueWasUpdated();
        }

        public void SetShowPeekAnimation()
        {
            showPeek = peek_toggle.isOn;
            ValueWasUpdated();
        }
    }
}