﻿using UnityEngine;
using System.Collections;

namespace Match2 {
		
	public class CardView : MonoBehaviour {

		GameObject face;
		GameObject back;
		Renderer faceRenderer;
		Renderer backRenderer;

		private BoxCollider2D c2d;

		Flip flipController;

		// reference index for this card
		public int refIdx;
		public bool isMatched = false;

		// Use this for initialization
		void Awake () {
			// test for now
			InitGameObject();
		}

		private void InitGameObject () {

			// create front (flipped 180)
			face = GameObject.CreatePrimitive(PrimitiveType.Quad);
			face.name = "face";
			face.transform.parent = transform;
			Quaternion faceRotation = Quaternion.Euler (new Vector3 (0, 180, 0));
			face.transform.localRotation = faceRotation;
			face.transform.localPosition = Vector3.zero;
			faceRenderer = face.GetComponent<MeshRenderer> ();

			// create back
			back = GameObject.CreatePrimitive(PrimitiveType.Quad);
			back.name = "back";
			back.transform.parent = transform;
			back.transform.localPosition = Vector3.zero;
			backRenderer = back.GetComponent<MeshRenderer> ();

			// create our hitbox for mouseOver detection
			c2d = gameObject.AddComponent<BoxCollider2D>();

			// add flip component
			flipController = gameObject.AddComponent<Flip>();

            // add selector-highlight component
            gameObject.AddComponent<CardSelector> ();
            

			// set the default size and aspect of our card
			SetDefaultSize();

			SetDefaultFaceTexture ();
			SetDefaultDeckTexture ();
		}

		private void SetDefaultSize () {

			// fetch our default size
			Vector2 size = new Vector2 (GlobalVars.CardWidth, GlobalVars.CardWidth * GlobalVars.CardAspect);
			SetSize (size);
		}

		private void SetDefaultFaceTexture () {
			Material mat = Resources.Load ("materials/card_front") as Material;

			if(mat)
				faceRenderer.sharedMaterial = mat;
		}

		private void SetDefaultDeckTexture () {
			Material mat = Resources.Load ("materials/card_back") as Material;

			if(mat)
				backRenderer.sharedMaterial = mat;
		}

		public void SetSize (Vector2 size) {
			if (!face || !back) {
				Debug.LogError ("Error - Card: Card back or front not initialised! Cannot SetSize()");
			}

			// the scale we will use
			Vector3 cardScale = new Vector3 (size.x, size.y, 1f);

			// set local scale for our card quads
			face.transform.localScale = cardScale;
			back.transform.localScale = cardScale;

			// update our hitbox
			c2d.size = cardScale;
		}

		public void SetFaceTexture (Texture2D texture) {
			if (!faceRenderer) {
				Debug.LogError ("Error - Card: Card back or front not initialised! Cannot SetFaceTexture()");
			}

			faceRenderer.material.SetTexture ("_MainTex", texture);
		}

		public void SetDeckTexture (Texture2D texture) {
			if (!backRenderer) {
				Debug.LogError ("Error - Card: Card back or front not initialised! Cannot SetBackTexture()");
			}

			backRenderer.material.SetTexture ("_MainTex", texture);
		}

		private void ResetFlipController(){
			if(flipController.enabled){
				flipController.StopAllCoroutines();
				flipController.enabled = false;
			}
		}

		public void FlipUp(){
			ResetFlipController();
			flipController.targetFacing = 0;
			flipController.enabled = true;
		}

		public void FlipDown(){
			ResetFlipController();
			flipController.targetFacing = 1;
			flipController.enabled = true;
		}

		public void SetMatched() {
			isMatched = true;
		}

		IEnumerator OnMouseDown () {

			if(isMatched)
				yield break;
			
			// if input is enabled, flip the card and wait
			GameManager _gm = GlobalVars.GameManager;

			// inform our input manager a card has been clicked
			_gm.CardClick(this);

			yield return null;
		}
	}
}