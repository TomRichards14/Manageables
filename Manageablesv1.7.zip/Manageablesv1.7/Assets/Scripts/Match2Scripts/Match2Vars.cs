﻿using UnityEngine;
using System.Collections;

namespace Match2 {

	public class AppVars {
        public const float SplashScreenDuration = 1.0f;
        public const float ScreenTransitionDuration = 0.5f;
        public const string BackgroundPrefabLocation = "prefabs/background";
		public const string ScreenTransitionsAnimationPrefabLocation = "prefabs/screen_transitions";
		public const string MainMenuPrefabLocation = "prefabs/menu";
        public const string MainMenuRootName = "menuRoot";
	}
	
	public class GlobalVars
    {

		// Gameobject Root
		public const string RootObjectName = "_GameRoot";

		// Game start vars
		public const float GameStartDelay = 0.5f;

		// Card view vars
		public const float flipTime = 0.35f;
		public const float FlipCheckDelay = 0.60f;
		public const float LookTime = 1.5f;

		// Card view size
		public const float CardWidth = 1.0f;
		public const float CardAspect = 1.554f;

		// Card Texture vars
		public const string CardSpriteLocation = "sprites/";
		public const string DefaultCardBack = "cardBack_";
		public const string DefaultCardFace = "card_";
		public const int numDecks = 4;
		public const int numFaces = 10;

		// Card spacing 
		public const float CardXSpacing = 0.1f;
		public const float CardYSpacing = 0.1f;

		// Current game state (if this is null, defaults will be used)
		private static GameConfig _globalConfig;
		public static GameConfig GameStateConfig { 
			get{
				// if for whatever reason our config hasn't been set up, create a default one
				return _globalConfig == null ? new GameConfig() : _globalConfig;
			}
			set {
				_globalConfig = value;
			}
		}

		// Current game manager instance, if there is one
		public static GameManager GameManager { get; set; }

		// Game defaults
		public const int GameDefaults_GridX = 4;
		public const int GameDefaults_GridY = 4;
		public const int GameDefaults_MatchLength = 2;
        public const int GameDefaults_DeckTextureIdx = 0;
        public const bool GameDefaults_ShowPeekAnimation = true;

        // Max grid sizes
        public const int MinGridX = 2;
        public const int MaxGridX = 7;
        public const int MinGridY = 2;
        public const int MaxGridY = 6;
    }

	public class GameConfig
    {

		// grid size
		public int GridX;
		public int GridY;

		// number of cards required for a match
		public int matchLength;

		// whether or not to show the cards on start
		public bool showPeekAnimation;

		// the index of the card back selected
		public int deckTextureIdx;

		public GameConfig(){
            GridX = GlobalVars.GameDefaults_GridX;
            GridY = GlobalVars.GameDefaults_GridY;
			matchLength = GlobalVars.GameDefaults_MatchLength;
			deckTextureIdx = GlobalVars.GameDefaults_DeckTextureIdx;
			showPeekAnimation = GlobalVars.GameDefaults_ShowPeekAnimation;
		}
	}
}