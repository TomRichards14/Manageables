﻿using UnityEngine;
using System.Collections;

public class DummyObject : MonoBehaviour {
	// dummy object script. used for non monobehaviour scripts. 
    // Script used in GameManager, Match2GridManager, MenuController 
	public static DummyObject _instance;
	public static DummyObject GetInstance()
    {

		if (_instance == null) {
			Initialize ();
		}

		return _instance;
	}

	static void Initialize () {
		GameObject dummy = new GameObject ("coroutine_dummy");
		_instance = dummy.AddComponent<DummyObject> ();
	}

}
