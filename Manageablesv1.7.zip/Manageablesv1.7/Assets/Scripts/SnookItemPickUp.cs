﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SnookItemPickUp : MonoBehaviour {

    

    // Use this for initialization
    void Start ()
    {
        
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    void OnCollisionEnter(Collision CheckIfItem)
    {
        //This checks for the tag on the object that collided with it
        if (CheckIfItem.gameObject.tag == "Snake")
        {
            //If the tags match then the pellet is destroyed
            Destroy(gameObject);
            //This allows access to functions and variables in my other script. So the bool changes so that another item spawns in, as well as calling the function to add another body part and also increases the player score
            GameObject.Find("GameManager").GetComponent<SnookGameManager>().ItemAvailable = false;
            GameObject.Find("GameManager").GetComponent<SnookGameManager>().AddToSnake();
            GameObject.Find("GameManager").GetComponent<SnookGameManager>().CurrentPlayerScore += 1;
        }
    }
}
