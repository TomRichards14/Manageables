﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SceneManagerR : MonoBehaviour {
    
    public void LoadScene(string Load)
    {
        SceneManager.LoadScene(Load); //load scene ranchlevel.
    }

    public void QuitApp()
    {
        Application.Quit(); //closes app.
    }
}
