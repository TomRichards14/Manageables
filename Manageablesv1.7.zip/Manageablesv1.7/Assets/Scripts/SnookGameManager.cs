﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SnookGameManager : MonoBehaviour {

    //This is similar to an array but instead I am using a list to store a table of the body parts
    public List<Transform> SnakeBody = new List<Transform>();

    //These are the 2 game objects that are mainly used, the snake body prefab and the item that the player picks up prefab
    public GameObject snakePrefab;
    public GameObject itemPrefab;

    //This is used for going through the list and checking each snake body position
    public Transform CurrentSnakeBlock;
    public Transform PreviousSnakeBlock;

    //These are the UI elements linked within this scene
    public Text CurrentPlayerScoreUIText;
    public Text FoodEarnedUIText;
    public GameObject MainGameUI;
    public GameObject GameOverUI;

    //This checks to see if an item has spawned or not and also if the game is over or not
    public bool ItemAvailable;
    public bool IsGameOver;

    //These floats determine the distance between each body part as well as the speed that the player rotates and also sets a float for the minimum distance between each body part before the player loses
    public float BodyMinDistance = 0.1f;
    public float SnakeRotationSpeed = 0.25f;
    private float DistanceBetweenBodyParts;
    private float CheckBodyCollision;

    //These ints are for how long I want the starting snake to be and also has an int for the player score in the current game
    public int SnakeStartSize = 3;
    public int CurrentPlayerScore;

    

    // Use this for initialization
    void Start ()
    {
        //This loops this function until the number of objects in the list matches the snake start size int
        for (int j = 0; j < SnakeStartSize; j++ )
        {
            AddToSnake();
        } 

        //This sets both bools to false to make sure that the game spawns an item to pick up and also to ensure that it's playable as the game isn't over yet
        ItemAvailable = false;
        IsGameOver = false;

        //This resets the current player score each game
        CurrentPlayerScore = 0;
	}
	
	// Update is called once per frame
	void Update ()
    {
        //If the bool is false then it calls a function to spawn an item in
        if (ItemAvailable == false)
        {
            ItemSpawn();
        }

        //If the bool is true then the game is over and the game has to change UI cavases and also display the currency earned
        if (IsGameOver == true)
        {
            int FoodEarned;

            MainGameUI.SetActive(false);
            GameOverUI.SetActive(true);

            FoodEarned = CurrentPlayerScore * 3;
            FoodEarnedUIText.text = ("+ " + FoodEarned);
        }

        //These 2 functions are called every frame as the snake needs to be moving constantly and also the game needs to check that the player isn't running into itself which would mean they would lose
        SnakeMovement();
        CheckIfHeadIsInBody();

        //This constantly keeps the score UI text updated
        CurrentPlayerScoreUIText.text = ("Score: " + CurrentPlayerScore.ToString());
	}

    void ItemSpawn()
    {
        //These two floats are for where the item could spawn
        float XCoord;
        float ZCoord;

        //This picks a random X and Z coodinate between boundaries for the item to spawn
        XCoord = Random.Range(-4.25f, 4.25f);
        ZCoord = Random.Range(-8.0f, 8.0f);

        //This instantiates the prefab at the chosen X and Z coordinates
        Instantiate(itemPrefab, new Vector3(XCoord, 0.31f, ZCoord), Quaternion.identity);

        //This sets the bool to true otherwise there would be constant items spawning
        ItemAvailable = true;
    }

    void SnakeMovement()
    {
        //This first if statement sets the bounds for the player, so if they go past these coords then the game ends
        if ((SnakeBody[0].transform.position.x < 4.6f) && (SnakeBody[0].transform.position.x > -4.6f) && (SnakeBody[0].transform.position.z < 8.0f) && (SnakeBody[0].transform.position.z > -8.0f) && (IsGameOver == false))
        {
            //This is the speed that the snake moves at
            float SnakeSpeed = 1.25f;
            
            //This moves only the head of the snake
            SnakeBody[0].Translate(SnakeBody[0].forward * SnakeSpeed * Time.smoothDeltaTime);

            //This if statement takes the button inputs from the user (A and D) and rotates the head based on how long they hold down the button for
            if (Input.GetAxis("Horizontal") != 0)
            {
                SnakeBody[0].Rotate(Vector3.up * SnakeRotationSpeed * Time.deltaTime * Input.GetAxis("Horizontal"));
            }

            if (Input.touchCount == 1)
            {
                Touch UserTouch = Input.GetTouch(0);

                if (UserTouch.phase == TouchPhase.Began)
                {
                    if (UserTouch.position.x > Screen.width/2)
                    {
                        SnakeBody[0].Rotate(Vector3.up * SnakeRotationSpeed * Time.deltaTime * UserTouch.position.x);
                    }
                    else if (UserTouch.position.x < Screen.width/2)
                    {
                        SnakeBody[0].Rotate(Vector3.up * SnakeRotationSpeed * Time.deltaTime * UserTouch.position.x);
                    }
                }
            }

            //This for loop goes through each body part in the list (apart from the head) and basically moves the snakes position to the position of the body part above it in the list
            for (int i = 1; i < SnakeBody.Count; i++)
            {
                CurrentSnakeBlock = SnakeBody[i];
                PreviousSnakeBlock = SnakeBody[i - 1];

                DistanceBetweenBodyParts = Vector3.Distance(CurrentSnakeBlock.position, PreviousSnakeBlock.position);

                Vector3 TargetLocation = PreviousSnakeBlock.position;

                TargetLocation.y = SnakeBody[0].position.y;
                //This speeds up the process the further away the body part is from the other
                float MoveToTargetSpeed = Time.deltaTime * DistanceBetweenBodyParts / BodyMinDistance * SnakeSpeed;
                //This maxes out the speed to make sure it doesn't move too fast
                if (MoveToTargetSpeed > 0.5f)
                {
                    MoveToTargetSpeed = 0.5f;
                }
                //Slerp is basically a function that moves an object from one position to another by a certain speed and by constantly doing this we have a snake
                CurrentSnakeBlock.position = Vector3.Slerp(CurrentSnakeBlock.position, TargetLocation, MoveToTargetSpeed);
                CurrentSnakeBlock.rotation = Quaternion.Slerp(CurrentSnakeBlock.rotation, PreviousSnakeBlock.rotation, MoveToTargetSpeed);
            }
        }
        else
        {
            //If the player exceeds the bounds then the game ends
            IsGameOver = true;
        }
    }

    public void AddToSnake()
    {
        //This adds a snake body part as a transform instead of a game object and spawns it at the current position of the last instantiated body part
        Transform NewSnakeBlock = (Instantiate(snakePrefab, SnakeBody[SnakeBody.Count - 1].position, SnakeBody[SnakeBody.Count - 1].rotation) as GameObject).transform;
        //This sets the parent as the head so it inherits from it
        NewSnakeBlock.SetParent(transform);
        //This adds the new body part to the list
        SnakeBody.Add(NewSnakeBlock);
    }

    void CheckIfHeadIsInBody()
    {
        //This for loop goes through each body part
        for (int i = 1; i < SnakeBody.Count; i++)
        {
            //This checks the distance between the head and the part of the body that we're currently looking at
            CheckBodyCollision = Vector3.Distance(SnakeBody[0].transform.position, SnakeBody[i].transform.position);
            //If the distance is below a certain number and the list has more than 2 elements in it then the game ends
            if ((CheckBodyCollision < 0.7f) && (SnakeBody.Count > 2))
            {
                IsGameOver = true;
            }
        }
    }
}
