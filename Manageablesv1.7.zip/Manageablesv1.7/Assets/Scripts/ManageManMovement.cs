﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ManageManMovement : MonoBehaviour {

    //This is how fast the player moves
    public float PlayerSpeed = 0.8f;
    //This variable is for touch screen controls by making a minimum distance to register as a swipe instead of a tap
    private float MinimumFingerSwipeDistance;
    //This is the player score for this current game
    public int CurrentPlayerScore;
    //This checks to see if the game is over or not based on certain criteria
    public bool IsGameOver;
    //This keeps the direction in which the player is currently moving
    public Vector3 PlayerDirection = Vector3.zero;
    //These variables are for the touch screen controls
    private Vector3 InitialTouchPos;
    private Vector3 LastTouchPos;
    //These are all the UI elements that it links too
    public Text CurrentPlayerScoreUIText;
    public Text FoodEarnedUIText;
    public GameObject MainGameUI;
    public GameObject GameOverUI;

	// Use this for initialization
	void Start ()
    {
        //This initializes the player score and sets up the UI text for the score, also sets the game over bool to false as the game is not over
        CurrentPlayerScore = 0;
        CurrentPlayerScoreUIText.text = ("Score : " + CurrentPlayerScore.ToString());
        IsGameOver = false;
        //This is measuring a swipe, making sure that's it's a swipe and not just a tap. The finger has to move a certain amount across the screen
        MinimumFingerSwipeDistance = Screen.height * 10 / 100;
    }

    // Update is called once per frame
    void Update ()
    {
        //This calls 2 functions as long as the game is not over
        if (IsGameOver == false)
        {
            GetPlayerDirection();
            PlayerMovement();
        }
        //This checks to see if the player has collected all the pellets in play, if they have then the game finishes
        if (CurrentPlayerScore == 53)
        {
            IsGameOver = true;
        }
        //When the game is over, this swaps over the UI cavases and displays how much currency the player has earned
        if (IsGameOver == true)
        {
            int FoodEarned;

            MainGameUI.SetActive(false);
            GameOverUI.SetActive(true);

            FoodEarned = CurrentPlayerScore;
            FoodEarnedUIText.text = ("+ " + FoodEarned.ToString());
        }
	}

    void GetPlayerDirection()
    {
        //If there is a finger on the screen
        if (Input.touchCount == 1)
        {
            Touch UserTouch = Input.GetTouch(0);
            //Gets the position of the touch on the screen
            if (UserTouch.phase == TouchPhase.Began)
            {
                //Assign the position of the touch to variables
                InitialTouchPos = UserTouch.position;
                LastTouchPos = UserTouch.position;
            }
            //If the finger has moved then change the last known position of the finger variable
            else if (UserTouch.phase == TouchPhase.Moved)
            {
                LastTouchPos = UserTouch.position;
            }
            //If the user has taken their finger off the screen, take the last position of the finger
            else if (UserTouch.phase == TouchPhase.Ended)
            {
                LastTouchPos = UserTouch.position;
                //Get the absolute value and check that it's higher than the threshold for the minimum swiping distance in either the X or Y axis
                if ((Mathf.Abs(LastTouchPos.x - InitialTouchPos.x) > MinimumFingerSwipeDistance) || (Mathf.Abs(LastTouchPos.y - InitialTouchPos.y) > MinimumFingerSwipeDistance))
                {
                    //This gets the direction of the swipe, if it's in the X or Y direction by seeing which absolute value is bigger
                    if (Mathf.Abs(LastTouchPos.x - InitialTouchPos.x) > (Mathf.Abs(LastTouchPos.y - InitialTouchPos.y)))
                    {
                        //If the last known X position is bigger then that means the user has swiped to the right and wants to move right
                        if (LastTouchPos.x > InitialTouchPos.x)
                        {
                            PlayerDirection = Vector3.right;
                        }
                        //If the last known X position is less than where the finger started on the screen then it's a left swipe
                        if (LastTouchPos.x < InitialTouchPos.x)
                        {
                            PlayerDirection = Vector3.left;
                        }
                    }
                    //This else is for if the Y axis absolute value is bigger
                    else
                    {
                        //If the last known Y pos it bigger then it's a swipe up
                        if (LastTouchPos.y > InitialTouchPos.y)
                        {
                            PlayerDirection = Vector3.forward;
                        }
                        //If the Y pos is less than the initial touch it's a swipe down
                        if (LastTouchPos.y < InitialTouchPos.y)
                        {
                            PlayerDirection = Vector3.back;
                        }
                    }
                }
            }
        }


        //This gets the key that is pressed from the user and it corresponds to a direction of movement
        if (Input.GetKeyDown(KeyCode.W))
        {
            PlayerDirection = Vector3.forward;
        }

        if (Input.GetKeyDown(KeyCode.A))
        {
            PlayerDirection = Vector3.left;
        }

        if (Input.GetKeyDown(KeyCode.S))
        {
            PlayerDirection = Vector3.back;
        }

        if (Input.GetKeyDown(KeyCode.D))
        {
            PlayerDirection = Vector3.right;
        }
    }

    void PlayerMovement()
    {
        //This makes sure that even though the player only presses the movement key once, they keep on moving in that direction
        transform.position += PlayerDirection * PlayerSpeed * Time.smoothDeltaTime;
    }

    void OnCollisionEnter(Collision CheckIfPellet)
    {
        //This checks the collision against the pellets which the user collects
        if ((CheckIfPellet.gameObject.tag == "Pellet") && (IsGameOver == false))
        {
            //Destroys the pellet on collision
            Destroy(CheckIfPellet.gameObject);
            //Adds one to the score of the player
            CurrentPlayerScore += 1;
            //Updates the UI text
            CurrentPlayerScoreUIText.text = ("Score : " + CurrentPlayerScore.ToString());
        }
        //Checks the collision against the enemy
        if (CheckIfPellet.gameObject.tag == "Enemy")
        {
            //If a collision occurs then the game is ove
            IsGameOver = true;
        }
    }

}
