﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SnookItemPickUp : MonoBehaviour {

    

    // Use this for initialization
    void Start ()
    {
        
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    void OnCollisionEnter(Collision CheckIfItem)
    {
        if (CheckIfItem.gameObject.tag == "Snake")
        {
            Destroy(gameObject);

            GameObject.Find("GameManager").GetComponent<SnookGameManager>().ItemAvailable = false;
            GameObject.Find("GameManager").GetComponent<SnookGameManager>().AddToSnake();
            GameObject.Find("GameManager").GetComponent<SnookGameManager>().CurrentPlayerScore += 1;
        }
    }
}
