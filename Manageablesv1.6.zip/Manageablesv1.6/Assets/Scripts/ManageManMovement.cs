﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ManageManMovement : MonoBehaviour {

    public float PlayerSpeed = 0.8f;

    public int CurrentPlayerScore;

    public bool IsGameOver;

    public Vector3 PlayerDirection = Vector3.zero;

    public Text CurrentPlayerScoreUIText;
    public Text FoodEarnedUIText;
    public GameObject MainGameUI;
    public GameObject GameOverUI;

	// Use this for initialization
	void Start ()
    {
        CurrentPlayerScore = 0;
        CurrentPlayerScoreUIText.text = ("Score : " + CurrentPlayerScore.ToString());
        IsGameOver = false;
    }

    // Update is called once per frame
    void Update ()
    {
        if (IsGameOver == false)
        {
            GetPlayerDirection();
            PlayerMovement();
        }

        if (CurrentPlayerScore == 53)
        {
            IsGameOver = true;
        }

        if (IsGameOver == true)
        {
            int FoodEarned;

            MainGameUI.SetActive(false);
            GameOverUI.SetActive(true);

            FoodEarned = CurrentPlayerScore;
            FoodEarnedUIText.text = ("+ " + FoodEarned.ToString());
        }
	}

    void GetPlayerDirection()
    {
        if (Input.GetKeyDown(KeyCode.W))
        {
            PlayerDirection = Vector3.forward;
        }

        if (Input.GetKeyDown(KeyCode.A))
        {
            PlayerDirection = Vector3.left;
        }

        if (Input.GetKeyDown(KeyCode.S))
        {
            PlayerDirection = Vector3.back;
        }

        if (Input.GetKeyDown(KeyCode.D))
        {
            PlayerDirection = Vector3.right;
        }
    }

    void PlayerMovement()
    {
        transform.position += PlayerDirection * PlayerSpeed * Time.smoothDeltaTime;
    }

    void OnCollisionEnter(Collision CheckIfPellet)
    {
        if (CheckIfPellet.gameObject.tag == "Pellet")
        {
            Destroy(CheckIfPellet.gameObject);
            CurrentPlayerScore += 1;
            CurrentPlayerScoreUIText.text = ("Score : " + CurrentPlayerScore.ToString());
        }

        if (CheckIfPellet.gameObject.tag == "Enemy")
        {
            IsGameOver = true;
        }
    }

}
