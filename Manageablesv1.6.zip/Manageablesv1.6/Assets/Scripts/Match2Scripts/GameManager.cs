﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Match2 {
		
	public class GameManager
    {
		private Match2State state;
        private List<int> cardselected;
        public bool InputEnabled { get; set; } // is. input being accepted?
		
		public IEnumerator Initialize ()
        {
            InputEnabled = false;
            cardselected = new List<int>();

            yield return new WaitForSeconds (0.5f);
            
			GameConfig gc = GlobalVars.GameStateConfig != null ? GlobalVars.GameStateConfig : new GameConfig();
			state = new Match2State();
			state.GridX = gc.GridX;
			state.GridY = gc.GridY;
			state.matchLength = gc.matchLength;


			GridManager gm = GridManager.GetInstance (); //make grid.
            gm.CreateGrid(state);
            gm.ShuffleGrid(state);
            gm.InitializeGridCardViews (state);
            gm.Spacing (state);
            gm.Textures(state);

			yield return new WaitForSeconds (2.0f);
		}

		public IEnumerator ShowGridStartGame () //shows the player the grid of cards and lets them see them for a few seconds.
        {

			GridManager gm = GridManager.GetInstance ();
            GameConfig gc = GlobalVars.GameStateConfig;

			if (gc.showPeekAnimation)
            {
				float delay = 0.5f;
				float LookTime = GlobalVars.LookTime;
				float flipTime = GlobalVars.flipTime;

                gm.Look(delay, LookTime);
				yield return new WaitForSeconds (delay + LookTime + flipTime);
			}
			StartGame();
		}

		void StartGame ()
        {
			InputEnabled = true;
		}

		public void CardClick (CardView cardView)
        {

			if (!InputEnabled)
            {
				return;
			}
			int cardIndex = cardView.refIdx;
			if (cardselected.Contains (cardIndex))
            {
				return;
			}
			cardView.FlipUp ();
            cardselected.Add (cardIndex);
			if (cardselected.Count == state.matchLength)//check match.
            {
				InputEnabled = false;
                DummyObject.GetInstance().StartCoroutine(CheckMatch ());
			}
		}

		IEnumerator CheckMatch ()
        {
			int[] indexes = cardselected.ToArray ();
			bool matchFound = state.MatchWasSuccessful (indexes);
            GridManager gm = GridManager.GetInstance ();

			yield return new WaitForSeconds(GlobalVars.FlipCheckDelay); //reset cards after x amount of time.

			if (matchFound)
            {
                gm.SetCardViewsMatched (indexes);
			} else
            {
                gm.FlipAllUnmatchedCardsDown ();
				yield return new WaitForSeconds(GlobalVars.flipTime * 0.5f);
			}

            cardselected = new List<int> ();

			if (state.IsComplete ())
            {
                DummyObject.GetInstance().StartCoroutine(GameComplete());
				yield break;
			}

			InputEnabled = true;
		}

		IEnumerator GameComplete ()
        {
			yield return 0;
			GameObject.Destroy(GameObject.Find(GlobalVars.RootObjectName));
            MenuController.RequestTransition(Screens.COMPLETION_UI, null);

        }
	}
}