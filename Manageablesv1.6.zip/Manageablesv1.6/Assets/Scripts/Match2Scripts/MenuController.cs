﻿using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;

namespace Match2 {

	public enum TransitionTypes { SLIDE_UP, SLIDE_DOWN, SLIDE_LEFT, SLIDE_RIGHT };
	public enum Screens { SPLASH, MAIN_MENU, OPTIONS_MENU, GAME_UI, COMPLETION_UI };
	public enum SlideDirections { UP, DOWN, LEFT, RIGHT }

	public class TransitionMapping {
		public TransitionTypes type;
		public Screens dest;
		public Screens orig;
		public TransitionMapping(TransitionTypes t, Screens o, Screens d){
			type = t;
			dest = d;
			orig = o;
		}
	}
		
	public class MenuController : MonoBehaviour {

		// ================================= Transition Mappings ==================================

		// Transition Definitions
		// - Splash -> Main Menu							BATTLE
		// - Main Menu -> Options 							SLIDE_LEFT
		// - Main Menu -> Game								BATTLE
		// - Options -> Main Menu							SLIDE_RIGHT
		// - Game UI -> Main Menu							BATTLE
		// - Game UI -> Completion Screen					SLIDE_LEFT
		// - Completion Screen -> Main Menu					BATTLE
		// - Completion Screen -> Game UI (Play Again)		BATTLE

		private List<TransitionMapping> _TransitionMappings = new List<TransitionMapping>() {
			// - Splash -> Main Menu					
			new TransitionMapping ( 
				TransitionTypes.SLIDE_UP,
				Screens.SPLASH,
				Screens.MAIN_MENU
			),
			// - Main Menu -> Options 
			new TransitionMapping (
				TransitionTypes.SLIDE_LEFT,
				Screens.MAIN_MENU,
				Screens.OPTIONS_MENU
			),
			// - Main Menu -> Game	
			new TransitionMapping (
				TransitionTypes.SLIDE_UP,
				Screens.MAIN_MENU,
				Screens.GAME_UI
			),
			// - Options -> Main Menu
			new TransitionMapping (
				TransitionTypes.SLIDE_RIGHT,
				Screens.OPTIONS_MENU,
				Screens.MAIN_MENU
			),
			// - Game UI -> Main Menu
			new TransitionMapping (
				TransitionTypes.SLIDE_DOWN,
				Screens.GAME_UI,
				Screens.MAIN_MENU
			),
			// - Game UI -> Completion Screen
			new TransitionMapping (
				TransitionTypes.SLIDE_LEFT,
				Screens.GAME_UI,
				Screens.COMPLETION_UI
			),
			// - Completion Screen -> Main Menu		
			new TransitionMapping (
				TransitionTypes.SLIDE_DOWN,
				Screens.COMPLETION_UI,
				Screens.MAIN_MENU
			),
			// - Completion Screen -> Game UI (Play Again)
			new TransitionMapping (
				TransitionTypes.SLIDE_RIGHT,
				Screens.COMPLETION_UI,
				Screens.GAME_UI
			)
		};

		// ============== Vars ==============

		private Screens _currentScreenType = Screens.SPLASH;

		private bool transitionInProgress = false;

        private RectTransform _splash;
		private RectTransform _mainMenu;
		private RectTransform _OptionsMenu;
		private RectTransform _GameUI;
		private RectTransform _CompletionScreenUI;

		void Awake(){
            // Ensure root has the correct name
            gameObject.name = AppVars.MainMenuRootName;

            // Find the UI panels
            GameObject pnl_Splash       = GameObject.Find("pnl_Splash");
            GameObject pnl_MainMenu 	= GameObject.Find("pnl_MainMenu");
			GameObject pnl_OptionsMenu 	= GameObject.Find("pnl_OptionsMenu");
			GameObject pnl_GameUI 		= GameObject.Find("pnl_GameUI");
			GameObject pnl_CompletionUI = GameObject.Find("pnl_CompletionUI");

            // Store their rect transforms
            _splash = pnl_Splash.GetComponent<RectTransform>();
			_mainMenu = pnl_MainMenu.GetComponent<RectTransform>();
			_OptionsMenu = pnl_OptionsMenu.GetComponent<RectTransform>();
			_GameUI = pnl_GameUI.GetComponent<RectTransform>();
			_CompletionScreenUI = pnl_CompletionUI.GetComponent<RectTransform>();

            // move extrenuous elements out of the way and disable them until they are needed
            _splash.gameObject.SetActive(true);
            _mainMenu.gameObject.SetActive(false);
			_OptionsMenu.gameObject.SetActive(false);
			_GameUI.gameObject.SetActive(false);
			_CompletionScreenUI.gameObject.SetActive(false);

            // initiate transition from splash to main menu
            DummyObject.GetInstance().StartCoroutine(SplashDelay());
		}

        private IEnumerator SplashDelay()
        {
            yield return new WaitForSeconds(AppVars.SplashScreenDuration);
            StartTransition(Screens.MAIN_MENU, null);
        }

		// ============================ Transition Animations ==================================

        public static void RequestTransition(Screens destination, Action cb = null)
        {
            GameObject menuRoot = GameObject.Find(AppVars.MainMenuRootName);
            if(menuRoot != null)
            {
                MenuController mc = menuRoot.GetComponent<MenuController>();
                if(mc != null)
                {
                    mc.StartTransition(destination, cb != null ? cb : null);
                }
            }
        }

		private void StartTransition(Screens destination, Action cb = null){
			StartCoroutine(Co_StartTransition(destination, cb != null ? cb : null));
		}

		private IEnumerator Co_StartTransition(Screens destination, Action cb = null){
			
			if(transitionInProgress){
				yield break;
			}

			transitionInProgress = true;

			// find the transition type
			TransitionTypes transitionType = GetTransitionType(destination);

			Debug.Log("Menu Transition: Type: " + transitionType.ToString() 
						+ " Origin: " + _currentScreenType.ToString() 
						+ " Destination: " + destination.ToString());

			// choose which one to play
			switch(transitionType){
				
				case TransitionTypes.SLIDE_UP:
					yield return StartCoroutine(Transition_Slide(SlideDirections.UP, destination, cb != null ? cb : null));
					break;

                case TransitionTypes.SLIDE_DOWN:
                    yield return StartCoroutine(Transition_Slide(SlideDirections.DOWN, destination, cb != null ? cb : null));
                    break;

                case TransitionTypes.SLIDE_LEFT:
					yield return StartCoroutine(Transition_Slide(SlideDirections.LEFT, destination, cb != null ? cb : null));
					break;

				case TransitionTypes.SLIDE_RIGHT:
					yield return StartCoroutine(Transition_Slide(SlideDirections.RIGHT, destination, cb != null ? cb : null));
					break;
			}

			// switch to the current screen and re-enable transitions
			_currentScreenType = destination;
			transitionInProgress = false;
		}

		private TransitionTypes GetTransitionType(Screens destination){
			
			// find out which transition type we need based on
			foreach(TransitionMapping tm in _TransitionMappings){
				if(tm.dest == destination && tm.orig == _currentScreenType){
					return tm.type;
				}
			}

            // default
			return TransitionTypes.SLIDE_LEFT;
		}

		private RectTransform GetScreenTransform(Screens screen){
			
			switch(screen){
				case Screens.SPLASH:
                    return _splash;

				case Screens.MAIN_MENU:
					return _mainMenu;

				case Screens.OPTIONS_MENU:
					return _OptionsMenu;

				case Screens.GAME_UI:
					return _GameUI;

				case Screens.COMPLETION_UI:
					return _CompletionScreenUI;

			}

			return null; // error, screen doesn't exist!
		}

		private IEnumerator Transition_Slide(SlideDirections direction, Screens destination, Action cb = null){

			RectTransform rt_origin = GetScreenTransform(_currentScreenType);
			RectTransform rt_destination = GetScreenTransform(destination);
            
            // activate the destination
			rt_destination.gameObject.SetActive(true);
            
            // work out our position values
            float duration = AppVars.ScreenTransitionDuration;
            float counter = 0f;
            Vector2 originInitialPosition = Vector2.zero;
            Vector2 originTargetPosition = GetOffScreenTargetPosition(direction);
            Vector2 destinationInitialPosition = originInitialPosition - originTargetPosition;
            Vector2 destinationTargetPosition = originInitialPosition;

            Debug.Log("duration: " + duration + " counter: " + counter);

            while(duration - counter > float.Epsilon)
            {
                float t = counter / duration;
                Vector2 origin_newPosition = Vector2.Lerp(originInitialPosition, originTargetPosition, t);
                Vector2 destination_newPosition = Vector2.Lerp(destinationInitialPosition, destinationTargetPosition, t);

                rt_origin.anchoredPosition = origin_newPosition;
                rt_destination.anchoredPosition = destination_newPosition;

                counter += Time.deltaTime;
                yield return 0;
            }

            // ensure they are in the correct positions
            rt_origin.anchoredPosition = originTargetPosition;
            rt_destination.anchoredPosition = destinationTargetPosition;

            // de-activate the origin now that it's off-screen
            rt_origin.gameObject.SetActive(false);

            // invoke our callback
            if (cb != null)
            {
                cb.Invoke();
            }

            yield break;
		}

        // ========================== Screen Transition Utils =================================

        public Vector2 GetOffScreenTargetPosition(SlideDirections direction)
        {
            // Assuming the screen center is world center
            Vector2 targetPosition = Vector2.zero;

            switch (direction)
            {
                case SlideDirections.UP:
                    targetPosition.y += GetWindowHeight(); 
                    break;

                case SlideDirections.DOWN:
                    targetPosition.y -= GetWindowHeight();
                    break;

                case SlideDirections.LEFT:
                    targetPosition.x -= GetWindowWidth();
                    break;

                case SlideDirections.RIGHT:
                    targetPosition.x += GetWindowWidth();
                    break;
            }

            return targetPosition;
        }

        public float GetWindowWidth()
        {
            return Screen.width;
        }

        public float GetWindowHeight()
        {
            return Screen.height;
        }

		// ================================ UI Callbacks ======================================

			// --- Main Menu UI ---

		// - btn_PLAY

		public void btnPress_MainMenu_Play(){
			// away we goooooooooooooooooo!
			// maybe this should be a separate transition specifically for starting the game... 
			Action cb = StartNewGame;
			StartTransition(Screens.GAME_UI, cb);
		}
		private void StartNewGame(){
			Debug.Log("Starting a new game!");

            // initialise the game bootstrapper, this will handle setting the game up
            Match2BootStrap.InitiateBoostrap();
		}

		// - btn_OPTIONS
		public void btnPress_MainMenu_Options(){
			// trigger Main Menu -> Options Menu transition
			StartTransition(Screens.OPTIONS_MENU);
		}

			// -- Options Menu UI ---

		// - btn_BACK
		public void btnPress_OptionsMenu_Back(){
			StartTransition(Screens.MAIN_MENU);
		}

			// --- Game UI ---

		// - btn_BACK/QUIT
		public void btnPress_GameUI_Back(){
            Action cb = CleanupGameInProgress;
            StartTransition(Screens.MAIN_MENU, cb);
		}
        private void CleanupGameInProgress()
        {
            Debug.Log("Exiting current game... Calling cleanup method...");
            Match2BootStrap.ExitGameInProgress();
        }

			// --- Completion Screen UI ---

		// - btn_BACK/QUIT
		public void btnPress_CompletionUI_Back(){
            Action cb = CleanupGameInProgress;
            StartTransition(Screens.MAIN_MENU, cb);
        }

		// - btn_PLAY AGAIN
		public void btnPress_CompletionUI_PlayAgain(){
            Action cb = StartNewGame;
            StartTransition(Screens.GAME_UI, cb);
		}

	}
}