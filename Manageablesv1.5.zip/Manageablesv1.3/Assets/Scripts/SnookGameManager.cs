﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SnookGameManager : MonoBehaviour {

    public List<Transform> SnakeBody = new List<Transform>();

    public GameObject snakePrefab;
    public GameObject itemPrefab;

    public Transform CurrentSnakeBlock;
    public Transform PreviousSnakeBlock;

    public Text CurrentPlayerScoreUIText;
    public Text FoodEarnedUIText;
    public GameObject MainGameUI;
    public GameObject GameOverUI;

    public bool ItemAvailable;
    public bool IsGameOver;

    public float BodyMinDistance = 0.1f;
    public float SnakeRotationSpeed = 0.25f;
    private float DistanceBetweenBodyParts;
    private float CheckBodyCollision;

    public int SnakeStartSize = 3;
    public int CurrentPlayerScore;

    

    // Use this for initialization
    void Start ()
    {
        for (int j = 0; j < SnakeStartSize; j++ )
        {
            AddToSnake();
        } 

        ItemAvailable = false;
        IsGameOver = false;

        CurrentPlayerScore = 0;
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (ItemAvailable == false)
        {
            ItemSpawn();
        }

        if (IsGameOver == true)
        {
            int FoodEarned;

            MainGameUI.SetActive(false);
            GameOverUI.SetActive(true);

            FoodEarned = CurrentPlayerScore * 3;
            FoodEarnedUIText.text = ("+ " + FoodEarned);
        }

        SnakeMovement();
        CheckIfHeadIsInBody();

        CurrentPlayerScoreUIText.text = ("Score: " + CurrentPlayerScore.ToString());
	}

    void ItemSpawn()
    {
        float XCoord;
        float ZCoord;

        XCoord = Random.Range(-4.25f, 4.25f);
        ZCoord = Random.Range(-8.0f, 8.0f);

        Instantiate(itemPrefab, new Vector3(XCoord, 0.31f, ZCoord), Quaternion.identity);

        ItemAvailable = true;
    }

    void SnakeMovement()
    {
        if ((SnakeBody[0].transform.position.x < 4.6f) && (SnakeBody[0].transform.position.x > -4.6f) && (SnakeBody[0].transform.position.z < 8.0f) && (SnakeBody[0].transform.position.z > -8.0f) && (IsGameOver == false))
        {
            float SnakeSpeed = 1.25f;

            SnakeBody[0].Translate(SnakeBody[0].forward * SnakeSpeed * Time.smoothDeltaTime);

            if (Input.GetAxis("Horizontal") != 0)
            {
                SnakeBody[0].Rotate(Vector3.up * SnakeRotationSpeed * Time.deltaTime * Input.GetAxis("Horizontal"));
            }

            for (int i = 1; i < SnakeBody.Count; i++)
            {
                CurrentSnakeBlock = SnakeBody[i];
                PreviousSnakeBlock = SnakeBody[i - 1];

                DistanceBetweenBodyParts = Vector3.Distance(CurrentSnakeBlock.position, PreviousSnakeBlock.position);

                Vector3 TargetLocation = PreviousSnakeBlock.position;

                TargetLocation.y = SnakeBody[0].position.y;

                float MoveToTargetSpeed = Time.deltaTime * DistanceBetweenBodyParts / BodyMinDistance * SnakeSpeed;

                if (MoveToTargetSpeed > 0.5f)
                {
                    MoveToTargetSpeed = 0.5f;
                }

                CurrentSnakeBlock.position = Vector3.Slerp(CurrentSnakeBlock.position, TargetLocation, MoveToTargetSpeed);
                CurrentSnakeBlock.rotation = Quaternion.Slerp(CurrentSnakeBlock.rotation, PreviousSnakeBlock.rotation, MoveToTargetSpeed);
            }
        }
        else
        {
            IsGameOver = true;
        }
    }

    public void AddToSnake()
    {
        Transform NewSnakeBlock = (Instantiate(snakePrefab, SnakeBody[SnakeBody.Count - 1].position, SnakeBody[SnakeBody.Count - 1].rotation) as GameObject).transform;

        NewSnakeBlock.SetParent(transform);

        SnakeBody.Add(NewSnakeBlock);
    }

    void CheckIfHeadIsInBody()
    {
        for (int i = 1; i < SnakeBody.Count; i++)
        {
            CheckBodyCollision = Vector3.Distance(SnakeBody[0].transform.position, SnakeBody[i].transform.position);
            if ((CheckBodyCollision < 0.7f) && (SnakeBody.Count > 2))
            {
                IsGameOver = true;
            }
        }
    }
}
