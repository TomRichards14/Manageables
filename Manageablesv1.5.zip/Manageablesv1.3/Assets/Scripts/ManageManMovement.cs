﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManageManMovement : MonoBehaviour {

    public float PlayerSpeed = 1.0f;
    public Vector3 PlayerDirection = Vector3.zero;

	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        GetPlayerDirection();
        PlayerMovement();
	}

    void GetPlayerDirection()
    {
        if (Input.GetKeyDown(KeyCode.W))
        {
            PlayerDirection = Vector3.forward;
        }

        if (Input.GetKeyDown(KeyCode.A))
        {
            PlayerDirection = Vector3.left;
        }

        if (Input.GetKeyDown(KeyCode.S))
        {
            PlayerDirection = Vector3.back;
        }

        if (Input.GetKeyDown(KeyCode.D))
        {
            PlayerDirection = Vector3.right;
        }
    }

    void PlayerMovement()
    {
        transform.position += PlayerDirection * PlayerSpeed * Time.smoothDeltaTime;
    }

    void OnCollisionEnter(Collision CheckIfPellet)
    {
        if (CheckIfPellet.gameObject.tag == "Pellet")
        {
            Destroy(CheckIfPellet.gameObject);
        }
    }

}
