﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class ManagemanEnemy : MonoBehaviour {


    public GameObject PlayerObject;
    private NavMeshAgent Enemy;

    // Use this for initialization
    void Start ()
    {
        Enemy = GetComponent<NavMeshAgent>();
    }
	
	// Update is called once per frame
	void Update ()
    {
        Enemy.SetDestination(PlayerObject.transform.position);
	}
}
