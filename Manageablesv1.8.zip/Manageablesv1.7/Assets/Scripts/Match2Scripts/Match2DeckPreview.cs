﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace Match2
{

    public class MenuDeckPreview : MonoBehaviour
    {
        // NOTE: back and prev buttons also call UpdateConfig() in MenuGameConfigurator
        //        this is how the value in the config is actually updated without this script
        //          needing to depend on MenuGameConfigurator

            // this could probable be done for a lot of the other options... to reduce complexity

        int max, min, deckIndex = 0;

        public RawImage rawImage;
        private Texture2D t2dPreviewImage;

        void Awake()
        {
            Initialize();
        }

        public int GetDeckIndex()
        {
            return deckIndex;
        }

        void Initialize()
        {
            // find our upper and lower boundaries
            CardTexturesManager texMan = CardTexturesManager.GetInstance();
            int maxDeckTextures = texMan.GetNumDeckTextures();
            deckIndex = 0;
            min = 0;
            max = maxDeckTextures;

            // fetch the initial image
            FetchDeckImage();
        }

        void FetchDeckImage()
        {
            int idx = deckIndex;
            CardTexturesManager texMan = CardTexturesManager.GetInstance();
            Texture2D t2d = texMan.GetDeckTexture(idx);
            if (t2d != null)
            {
                t2dPreviewImage = t2d;
                UpdatePreviewImage();
            }
        }

        void UpdatePreviewImage()
        {
            if (rawImage != null && t2dPreviewImage != null)
            {
                rawImage.texture = t2dPreviewImage;
            }
        }

        public void OnNextClicked()
        {
            deckIndex = Mathf.Clamp(deckIndex + 1, min, max);
            FetchDeckImage();
        }

        public void OnPrevClicked()
        {
            deckIndex = Mathf.Clamp(deckIndex - 1, min, max);
            FetchDeckImage();
        }
    }
}
