﻿using UnityEngine;
using System.Collections;

namespace Match2 {
	
	public class Match2State
    {

		public CardModel[] cards;
		public int matchLength;
        public int GridX, GridY;

        public int TotalMatchAttempts { get; set; }
		public int[] PreviousAttemptIndexes { get; set; }
        public int FailedMatchAttempts { get; set; }

        public Match2State() {
			FailedMatchAttempts = 0;
		}

		public bool MatchWasSuccessful(int[] cardIndexes) {
			CardModel[] cards_to_match = new CardModel[cardIndexes.Length];
			for (int i = 0; i < cardIndexes.Length; i++) {
				int index = cardIndexes [i];
				CardModel card = cards [index];
				cards_to_match [i] = card;
			}

			return MatchWasSuccessful (cards_to_match);
		}

		public bool MatchWasSuccessful(CardModel[] cards_to_match) {

			if (cards_to_match.Length <= 1) {
				Debug.LogWarning ("GameStateModel: Cannot attempt to match a single card to itself...");
				return false;
			}

			CardModel baseCard = cards_to_match [0];
			for (int i = 1; i < cards_to_match.Length; i++) {
				CardModel otherCard = cards_to_match [i];
				bool doesMatch = baseCard.FaceMatches(otherCard);
				if (!doesMatch) {
					return false;
				}
			}

			// if a match was a success, mark them as matched
			for (int i = 0; i < cards_to_match.Length; i++) {
				CardModel c = cards_to_match [i];
				c.MatchedState = true;
			}

			return true;
		}

		public bool IsComplete () {
			for (int i = 0; i < cards.Length; i++) {
				CardModel card = cards [i];
				if (card.MatchedState == false) {
					return false;
				}
			}

			return true;
		}
	}
}
