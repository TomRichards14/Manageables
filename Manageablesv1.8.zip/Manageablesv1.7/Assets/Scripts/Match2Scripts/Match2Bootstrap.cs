﻿using UnityEngine;
using System.Collections;

namespace Match2 {
		
	public class Match2BootStrap : MonoBehaviour
    {
		GameManager _gameManager;

		void Awake ()
        {
			_gameManager = new GameManager();
			StartCoroutine (Startup ());
		}

		public static void InitiateBoostrap()
        {
			GameObject bootstrap = new GameObject("bootstrap");
			bootstrap.AddComponent<Match2BootStrap>();
		}

        public static void ExitGameInProgress()
        {
            GameObject root = GameObject.Find(GlobalVars.RootObjectName);
            if(root != null)
            {
                GameObject.Destroy(root);
            }
        }


        IEnumerator Startup () {

			GameObject preExistingRoot = GameObject.Find(GlobalVars.RootObjectName);
			if (preExistingRoot != null)
            {
                Debug.LogError("Game already in progress");
			} else
            {
				// Start
				GameObject root = new GameObject();
                root.name = GlobalVars.RootObjectName;
                GlobalVars.GameManager = _gameManager;

				yield return StartCoroutine(_gameManager.Initialize());
				yield return  StartCoroutine(_gameManager.ShowGridStartGame());
			}				
			Destroy(gameObject);
		}
	}
}