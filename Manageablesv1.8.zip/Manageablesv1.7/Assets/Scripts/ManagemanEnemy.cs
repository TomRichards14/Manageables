﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class ManagemanEnemy : MonoBehaviour {

    //These variables are for the player object itself and also the enemy
    public GameObject PlayerObject;
    private NavMeshAgent Enemy;

    // Use this for initialization
    void Start ()
    {
        //This gets the NavMeshAgent componenet of the Enemy to allow me to change what it does
        Enemy = GetComponent<NavMeshAgent>();
    }
	
	// Update is called once per frame
	void Update ()
    {
        //This sets the destination of the enemy to be the position of the players position, essentially following them
        if (GameObject.Find("Player").GetComponent<ManageManMovement>().IsGameOver == false)
        {
            Enemy.SetDestination(PlayerObject.transform.position);
        }
        
	}
}
